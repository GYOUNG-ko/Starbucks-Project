package com.care.coffee.member;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;

@Controller
public class Admin_MemberController {
	@Autowired private Admin_MemberService admin_service ;
	@Autowired private HttpSession session;
	@Autowired private Admin_MemberMapper admin_mapper;
	
	@RequestMapping("/admin_memberInfo")
	public String admin_memberInfo(String select, String search,
			@RequestParam(value="currentPage", required = false) String cp, Model model) {
		admin_service.admin_memberInfo(select, search, cp, model);
		
		return "/admin/mem_memberInfo";
	}
	
	@GetMapping("/admin_userInfo")
	public String admin_userInfo(String userId, Model model,  RedirectAttributes ra) {
		String msg = admin_service.admin_userInfo(userId, model);
		if(msg.equals("회원 검색 완료"))
			return "/admin/mem_userInfo";
		
		ra.addFlashAttribute("msg", msg);
		return "redirect:/admin/mem_memberInfo";
	}
	
	//http://localhost:8086/dbQuiz/update
	@RequestMapping("admin_modify")
	public String admin_modify(String userId, Model model) {
		String sessionId = (String)session.getAttribute("userId");
		if(sessionId == null) {
			return "redirect:/login/login";
		}
		
		MemberDTO member = admin_service.getMember(userId);
		
		if(member == null) {
			return "redirect:/admin/mem_memberInfo";
		}
		String phone = (String)session.getAttribute("phone");
		System.out.println(phone);
		
		List<GradeDTO> grade = admin_mapper.gradeList();
		model.addAttribute("grade", grade);
		
		if(sessionId == null)
			return "redirect:/login/login";
		
		return "admin/mem_modify";
	}
	
	@PostMapping("admin_modifyProc")
	public String admin_modifyProc(MemberDTO member, Model model) {
		String sessionId = (String)session.getAttribute("userId");
		/*
		 * if(sessionId == null) return "redirect:/login";
		 */
		
		member.setUserId(sessionId);
		String msg = admin_service.admin_modifyProc(member);
		if(msg.equals("회원 수정 완료")) {
			return "redirect:/index";
		}
		
		model.addAttribute("msg", msg);
		return "mem/myinfo_modify";
	}
	
	
	//http://localhost:8086/dbQuiz/delete
	@RequestMapping("/admin_delete")
	public String admin_delete() {
	
//		 String sessionId = (String)session.getAttribute("userId"); if(sessionId ==
//		 null) return "redirect:/login";
//		 
		return "/admin/mem_delete";
	}
	
	@PostMapping("/amdin_deleteProc")
	public String amdim_deleteProc(MemberDTO member, Model model) {
		String sessionId = (String)session.getAttribute("userId");
		if(sessionId == null)
			return "redirect:/login/login";
		
		member.setUserId(sessionId);
		String msg = admin_service.admin_deleteProc(member);
		if(msg.equals("회원 삭제 완료")) {
			session.invalidate();
			return "redirect:index";
		}
		
		model.addAttribute("msg", msg);
		return "/admin/mem_delete";
	}
	
}
